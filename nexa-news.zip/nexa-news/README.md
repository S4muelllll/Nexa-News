# NEXA NEWS — Il mondo, messo a fuoco

NEXA NEWS è una rivista di notizie responsive con estetica editoriale scura, animazioni, ticker, ricerca, filtri, segnalibri, condivisione, tema chiaro/scuro, carosello in evidenza e flash card interattive. Il sito si adatta a smartphone e desktop e rispetta `prefers-reduced-motion`.

## Pubblicare su GitHub Pages

1. Estrai `nexa-news.zip`.
2. Crea su GitHub un repository chiamato `nexa-news`.
3. Carica nella **radice del repository** tutti i file della cartella `nexa-news`, inclusa la cartella nascosta `.github`.
4. In **Settings → Pages**, scegli **GitHub Actions** come origine di pubblicazione.
5. In **Actions**, abilita i workflow se richiesto e avvia **NEXA NEWS - aggiornamento automatico ogni 5 minuti → Run workflow** per il primo aggiornamento e il deploy.
6. A deploy completato, GitHub mostrerà l'indirizzo pubblico nelle impostazioni Pages; di solito è `https://TUO-USERNAME.github.io/nexa-news/`.

Il workflow contiene già il deploy Pages. Se il job non può pubblicare, controlla i permessi di Actions nelle impostazioni del repository. Il sito non è online finché non lo carichi su GitHub e Pages non completa il deploy.

## Aggiornamento automatico

Dopo l'attivazione, GitHub Actions interroga le fonti ogni **5 minuti** usando il fuso `Europe/Rome` e pubblica una nuova edizione quando cambiano le notizie. L'orario è sfalsato di due minuti rispetto all'ora tonda per ridurre la congestione. Se il contenuto non è cambiato, salta il nuovo deploy. GitHub può comunque avviare gli eventi pianificati in ritardo nei periodi di carico; puoi anche avviare manualmente il workflow dalla scheda **Actions**. La pagina già aperta ricarica i dati ogni cinque minuti.

## Notizie, immagini e flash card

- `update_news.py` raccoglie le notizie recenti tramite feed RSS di Google News e conserva solo risultati pubblicati da meno di 48 ore, pertinenti e attribuiti alle fonti ammesse in `TRUSTED_SOURCE_HINTS`.
- Tutti i risultati che superano i filtri e arrivano dai feed sono inclusi: i primi dieci costituiscono la selezione principale, gli altri diventano flash card aggiuntive. Non c'è un limite fisso al numero di storie o flash card; i duplicati vengono rimossi.
- Le immagini arrivano dai metadati RSS quando disponibili. Per le notizie senza foto il sistema ruota tra gli articoli e prova a recuperare l'immagine Open Graph/Twitter dalla pagina originale. Gli editori possono bloccare questo accesso o non fornire immagini, quindi in alcuni casi resta la grafica di categoria. Le immagini sono ospitate dagli editori e non vengono copiate nel repository.
- Le flash card mostrano il titolo sul fronte e un breve contesto sul retro, con collegamento alla fonte originale.
- Le descrizioni RSS sono anteprime automatiche, non verifiche giornalistiche. Consulta sempre l'articolo originale.
- Tema e segnalibri si salvano localmente nel browser; le animazioni rispettano l'impostazione di movimento ridotto del dispositivo.

## File del progetto

- `index.html` — rivista, visual e interazioni.
- `news.json` — dati dell'edizione e flash card.
- `update_news.py` — raccolta, filtro, deduplicazione e immagini.
- `.github/workflows/daily-news.yml` — aggiornamento e pubblicazione pianificati.

